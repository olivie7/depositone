<?php


$bdd = new PDO('mysql:host=localhost;dbname=wf3_ajax;charset=utf8', 'root', '');
